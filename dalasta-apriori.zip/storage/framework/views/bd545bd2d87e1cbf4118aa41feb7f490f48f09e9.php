<?php
$currentUrl = Request::segment(1);
//    $currentUrlCls = 'bg-slate-700 rounded-xl';
$currentUrlCls = 'active';
?>

<ul class="navbar-nav bg-white sidebar sidebar-dark accordion font-weight-bold toggled" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center" href="<?php echo e(route('home')); ?>">
        
        <div class="sidebar-brand-icon"> <img src="<?php echo e(asset('app-img/logo/logo-dalasta-icon-ai-small.png')); ?>" height="45px"></div>
        
        <div class="sidebar-brand-text"> <img src="<?php echo e(asset('app-img/logo-dalasta.png')); ?>" class="mt-2"  height="50px"></div>
    </a>

    <!-- Divider -->
    

    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php echo e($currentUrl == 'home' ? $currentUrlCls : ''); ?> mt-4" data-toggle="tooltip" data-placement="right"
        title="Home">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    
    <li class="nav-item <?php echo e($currentUrl == 'products' ? $currentUrlCls : ''); ?>" data-toggle="tooltip"
        data-placement="right" title="Products">
        <a class="nav-link" href="<?php echo e(route('products.index')); ?>">
            <i class="fas fa-fw fa-box"></i>
            <span>Product</span></a>
    </li>
    <li class="nav-item <?php echo e($currentUrl == 'transactions' ? $currentUrlCls : ''); ?>" data-toggle="tooltip"
        data-placement="right" title="Transactions">
        <a class="nav-link" href="<?php echo e(route('transactions.index')); ?>">
            <i class="fas fa-fw fa-money-bill-wave"></i>
            <span>Transaction</span></a>
    </li>
    <li class="nav-item <?php echo e($currentUrl == 'apriori-analysis' ? $currentUrlCls : ''); ?>" data-toggle="tooltip"
        data-placement="right" title="Apriori Analytics">
        <a class="nav-link" href="<?php echo e(route('apriori-analysis.index')); ?>">
            <i class="fas fa-fw fa-chart-bar"></i>
            <span>Apriori Analysis</span></a>
    </li>

    <hr class="sidebar-divider d-none d-md-block">
    

    
    
</ul>



<?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>