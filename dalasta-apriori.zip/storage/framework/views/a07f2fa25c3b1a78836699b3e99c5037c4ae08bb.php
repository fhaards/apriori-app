<div class="row row-eq-height two-sections">
    <!-- Area Chart -->
    <div class="col-xl-8 col-lg-7 align-self-stretch">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Earnings Overview</h6>
                
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="myAreaChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Pie Chart -->
    <div class="col-xl-4 col-lg-5 align-self-stretch" id="pie-chart-dashboard">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Revenue Sources</h6>
                
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-pie pt-5 pb-5 mb-4">
                    <canvas id="myPieChart"></canvas>
                </div>
                <div class="mt-1 small text-center">
                    <span class="mr-2 mb-2">
                        <i class="fas fa-circle text-chart-1"></i>
                        <span class="name_1"></span>
                    </span>
                    <span class="mr-2 mb-2">
                        <i class="fas fa-circle text-chart-2"></i>
                        <span class="name_2"></span>
                    </span>
                    <span class="mr-2 mb-2">
                        <i class="fas fa-circle text-chart-3"></i>
                        <span class="name_3"></span>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/dashboard/dashboard_cart.blade.php ENDPATH**/ ?>