

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.header-pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-sm-row flex-column justify-content-between align-items-center"
            id="header-transaction">
            <h6 class="m-0 font-weight-bold text-primary">Data <?php echo e($headerpages); ?></h6>
            <div class="d-flex flex-row mt-sm-0 mt-3">
                <button class="btn btn-sm btn-primary mr-2 open-filter">
                    <i class="fas fa-filter fa-sm fa-fw text-whtie"></i>
                </button>
                <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#transactionAddModal">
                    <i class="fas fa-plus fa-sm fa-fw mr-2 text-whtie"></i>
                    Add <?php echo e($headerpages); ?>

                </button>
            </div>
        </div>
        <div class="card-body px-0 py-0">
            <div id="filter-transaction" class="d-none mt-0 border-bottom">
                <div class="d-flex flex-sm-row flex-column justify-content-end bg-slate-300 px-2 pt-3 w-100">
                    <div class="filter-range">
                        <div class="form-group d-flex flex-sm-row flex-column align-items-center">
                            <span class="mr-sm-3 my-2 my-sm-0 col-sm-5  text-gray-900"><strong>Filter Date
                                    Range</strong></span>
                            <input type="text" class="form-control pull-right" id="datesearch"
                                placeholder="Search by date range..">
                            
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive px-3 mt-3 mb-3 py-3">
                <table class="table table-striped table-hover" id="table-transactions" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Transaction Id</th>
                            <th>Customer Name </th>
                            <th>Date Fake</th>
                            <th width="20%">Date Created</th>
                            <th width="5%">Qty</th>
                            <th>Total Price</th>
                            <th></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
    <?php echo $__env->make('transactions.transactions_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('transactions.transactions_add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js-app'); ?>
    <script src="<?php echo e(asset('js-app/app-transaction.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/transactions/transactions_table.blade.php ENDPATH**/ ?>