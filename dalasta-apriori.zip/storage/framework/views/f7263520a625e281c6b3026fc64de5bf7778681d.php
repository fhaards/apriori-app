<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('assets/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('js/sb-admin-2.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/layouts/jsfile.blade.php ENDPATH**/ ?>