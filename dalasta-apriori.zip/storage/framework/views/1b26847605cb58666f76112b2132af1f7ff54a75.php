<div class="d-sm-flex align-items-center justify-content-between mb-4 border-bottom pb-4">
    <h1 class="h3 mb-0 text-gray-900 font-weight-bolder"><?php echo e($headerpages); ?></h1>
</div>
<?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/layouts/header-pages.blade.php ENDPATH**/ ?>