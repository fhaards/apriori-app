

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.header-pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Data <?php echo e($headerpages); ?></h6>
            <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#productAddModal">
                <i class="fas fa-plus fa-sm fa-fw mr-2 text-whtie"></i>
                Add Products
            </button>
        </div>
        <div class="card-body text-sm">
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="table-products" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th width="20%">Name</th>
                            <th width="20%">Type</th>
                            <th width="15%">Price</th>
                            <th width="10%">Stock</th>
                            <th>Date Fake</th>
                            <th width="15%">Date Created</th>
                            <th width="10%"></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
    <?php echo $__env->make('products.products_add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('products.products_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js-app'); ?>
    <script src="<?php echo e(asset('js-app/app-products.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/products/products_table.blade.php ENDPATH**/ ?>