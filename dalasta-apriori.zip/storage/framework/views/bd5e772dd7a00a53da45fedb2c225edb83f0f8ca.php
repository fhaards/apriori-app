<div class="accordion my-3" id="combine-1">
    <div class="card">
        <div class="card-header bg-gray-900" type="button" id="heading-1" data-toggle="collapse"
            data-target="#collapse-1" aria-expanded="true" aria-controls="collapseOne">
            <h5 class="mb-0 text-white font-weight-bold">
                1 Product Combination
            </h5>
        </div>

        <div id="collapse-1" class="collapse show" aria-labelledby="heading-1" data-parent="#combine-1">
            <div class="card-body">
                <div class="mt-3">
                    <p>
                        Threshold Support = <?php echo e($ts1); ?> <br>
                        Threshold Support x Confidence = <?php echo e($tc1); ?>

                    </p>
                </div>
                <div class="table-responsive">
                    <table id="comb-1-proccess" class="mx-0 mb-0 py-0 table table-striped table-bordered" width="100%">
                        <thead>
                            <tr>
                                <th class="text-center">Product Name</th>
                                <th class="text-center">Support </th>
                                <th class="text-center">Confidence </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $combineFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proccess1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $countPrd = (float) $proccess1->count;
                                    $gsupport = $countPrd / $countTrans;
                                    $gconfide = $countPrd / $countPrd;
                                ?>
                                <tr>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            <?php echo e($proccess1->name); ?>

                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            Support = <?php echo e($countPrd); ?> / <?php echo e($countTrans); ?> = <?php echo e(number_format((float)$gsupport, 2, '.', '')); ?> 
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            Confidence = <?php echo e($countPrd); ?> / <?php echo e($countPrd); ?> = <?php echo e($gconfide); ?>

                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="text-center w-100 py-3 my-3">
                    <div class="my-0 py-0 h3"> COMBINATION RULES </div>
                </div>
                <div class="table-responsive">
                    <table id="comb-1-rules" class="mx-0 table table-striped table-bordered" width="100%">
                        <thead>
                            <tr>
                                <th class="text-center">Rules</th>
                                <th class="text-center">Support</th>
                                <th class="text-center">Confidence</th>
                                <th class="text-center">Support x Confidence</th>
                                <th class="text-center">Threshold Support</th>
                                <th class="text-center">Threshold Confidence</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $combineFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rules1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $prodname = $rules1->name;
                                    $countPrd = (float) $rules1->count;
                                    $gsupport = (float) $countPrd / $countTrans;
                                    $gconfide = (float) $countPrd / $countPrd;
                                    $supxconf = (float) $gsupport * $gconfide;
                                    if ($gsupport > $ts1) :
                                        $tsup = "YES";
                                    else :
                                        $tsup = "NO";
                                    endif;
                                    
                                    if ($gconfide > $tc1) :
                                        $tconf = "YES";
                                    else :
                                        $tconf = "NO";
                                    endif;
                                ?>
                                <tr>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            If buy <?php echo e($prodname); ?> Then buy <?php echo e($prodname); ?>

                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center"><?php echo e(number_format((float)$gsupport, 2, '.', '')); ?> </div>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center"> <?php echo e($gconfide); ?></div>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center"><?php echo e(number_format((float)$supxconf, 2, '.', '')); ?></div>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center"> <?php echo e($tsup); ?></div>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center"> <?php echo e($tconf); ?></div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/apriori/apriori_combine_1.blade.php ENDPATH**/ ?>