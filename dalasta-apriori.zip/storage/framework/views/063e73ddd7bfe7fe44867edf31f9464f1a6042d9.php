<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('app-img/logo/favicon.ico')); ?>">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="<?php echo e(asset('assets/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/css/sb-admin-2.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/datatables/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/sweetalert2/sweetalert2.material-ui.min.css')); ?>" media="all" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('assets/css/daterangepicker.css')); ?>" media="all" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/aos-master/dist/aos.css')); ?>" media="all" rel="stylesheet" type="text/css" />
    <!-- Custom -->
    <link href="<?php echo e(asset('assets/css/custom-color.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom-style.css')); ?>" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper" class="">
        <?php if(auth()->guard()->guest()): ?>
            <?php echo $__env->yieldContent('content-login'); ?>
        <?php else: ?>
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column bg-slate-50 px-0">
                <div id="content">
                    <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- Main Content -->
                    <div class="container-fluid py-sm-4 py-3 main-contents">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php echo $__env->yieldPushContent('modal'); ?>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('assets/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Datatables-->
    <script src="<?php echo e(asset('assets/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('assets/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('assets/js/sb-admin-2.js')); ?>"></script>
    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/daterangepicker.js')); ?>"></script>
    <!-- Carts -->
    <script src="<?php echo e(asset('assets/chart.js/Chart.min.js')); ?>"></script>
    <!-- Sweetalert -->
    <script src="<?php echo e(asset('assets/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/aos-master/dist/aos.js')); ?>" type="text/javascript"></script>

    <script>
        AOS.init();
        var APP_URL = <?php echo json_encode(url('/')); ?>

        var url = $(location).attr('href'),
            parts = url.split("/"),
            firstPart = parts[3];
        var WEB_URL = APP_URL + "/" + firstPart;
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
            },
        });
        // $(document).ready(function() {
        //     $('#dataTable').DataTable();
        // });
    </script>
    <?php echo $__env->yieldPushContent('js-app'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>