

<?php $__env->startSection('content'); ?>
    

    <?php echo $__env->make('layouts.header-pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="post" action="<?php echo e(route('apriori-analysis.store')); ?>" id="form-apriori">
        <?php echo csrf_field(); ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">Analyzing using Data Mining with Market Basket Analysis Methods
                </h6>
            </div>
            <div class="card-body text-sm">
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered" id="table-apriori" width="100%"
                        cellspacing="0">
                        <thead>
                            <tr>
                                <th>Combination Count</th>
                                <th>Threshold Support</th>
                                <th>Threshold Support x Confidence</th>
                            </tr>
                            <tr>
                                <td width="40%">1 Product</td>
                                <td width="25%"><input type="text" name="ts1" class="form-control w-25" value="0.2"></td>
                                <td width="25%"><input type="text" name="tc1" class="form-control w-25" value="0.1"></td>
                            </tr>
                            <tr>
                                <td width="40%">2 Product</td>
                                <td width="25%"><input type="text" name="ts2" class="form-control w-25" value="0.1"></td>
                                <td width="25%"><input type="text" name="tc2" class="form-control w-25" value="0.0"></td>
                            </tr>
                        </thead>
                    </table>
                </div>

            </div>
            <div class="card-footer d-flex justify-content-end">
                <button type="submit" class="submit-form-apriori btn btn-primary"> <i class="fas fa-save mr-2"></i>
                    PROCESS</button>
                
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-app'); ?>
    <script src="<?php echo e(asset('js-app/app-apriori.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/apriori/apriori_form.blade.php ENDPATH**/ ?>