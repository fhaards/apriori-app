<?php $__env->startSection('content'); ?>
    <div class="jumbotron py-sm-3 py-md-5 py-4 px-4 border text-dark rounded-xl" data-aos="fade-up" data-aos-anchor-placement="center-bottom">
        <h1 class="display-6 text-white" data-aos="fade-down" data-aos-delay="300">Hello, <?php echo e($user->name); ?></h1>
        <p class="mb-0 pb-0 text-gray-100" data-aos="fade-up" data-aos-delay="400">Welcome Back to <?php echo e(config('app.name', 'Laravel')); ?></p>
    </div>
    <?php echo $__env->make('dashboard.dashboard_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-app'); ?>
    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js-chart/dash-area.js')); ?>"></script>
    <script src="<?php echo e(asset('js-chart/dash-pie.js')); ?>"></script>
<?php $__env->stopPush(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apriori-ps-app\resources\views/home.blade.php ENDPATH**/ ?>