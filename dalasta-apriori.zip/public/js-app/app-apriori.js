var formApriori = $("#form-apriori");
var checkComb = formApriori.find("#count-combination");
var checkAll = formApriori.find("#checkall-checkbox");
var sumbitApriori = formApriori.find(".submit-form-apriori");
// sumbitApriori.prop("disabled", true);

// $("#form-apriori :checkbox").change(function () {
//     $(this).each(function () {
//         if ($(this).is(":checked")) {
//             if ($(this).length == 0) {
//                 sumbitApriori.prop("disabled", true);
//             } else {
//                 sumbitApriori.prop("disabled", false);
//             }
//         } else {
//             sumbitApriori.prop("disabled", true);
//         }
//     });
// });



